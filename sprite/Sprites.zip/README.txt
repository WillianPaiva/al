The Tibia sprites belong to Cipsoft.
Converted by TGYoshi.